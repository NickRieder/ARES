# CSE5236_Group14_ARES

# Group members:
# Josh Weible, Nick Rieder, Jared Zahn

This mobile application was designed & implemented for CSE 5236 - Mobile App Development [Instructor: Adam C. Champion, Ph.D.]

Hello and welcome to the README for our mobile application - ARES - which is aiming to help bridge the gap between auto-repair employers and their technical employees. ARES is an acronymn that is short for "Auto-Repair Employee Services" and will serve as an intuitive interface for logging employee hours, repair orders, vehicle information, and much more. Our app is designed to remove the hectic tornado of paperwork that can result from just a single repair order. By storing the repair orders online and being able to export/print them as excel spreadsheets will greatly optimize the process.

Download Instructions:
-
-

Application Installation Instructions:
-
-

Application Execution Instructions:
-
-

Helpful Resources:
-
-
