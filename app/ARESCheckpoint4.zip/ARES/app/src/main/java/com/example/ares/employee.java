package com.example.ares;

public class employee {
    private int id;
    private int employerId;
    private String username;
    private String password;
}
