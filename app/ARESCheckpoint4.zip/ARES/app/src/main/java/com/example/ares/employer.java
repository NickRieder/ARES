package com.example.ares;

public class employer {
    private int id;
    private String username;
    private String password;
    private String status;
    private int[] employeeList;
}
